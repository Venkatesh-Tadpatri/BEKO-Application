/**
 * PDF Report Template Generator
 * Generates HTML content for Filter Housing Selection Report
 */

/**
 * Format current date and time
 * @returns {string} Formatted date string (DD/MM/YYYY, HH:MM:SS)
 */
const formatDate = () => {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const year = now.getFullYear();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  return `${day}/${month}/${year}, ${hours}:${minutes}:${seconds}`;
};

/**
 * Format date for filename (DDMMYYYY)
 */
const formatDateForFilename = () => {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const year = now.getFullYear();
  return `${day}${month}${year}`;
};

/**
 * Generate PDF HTML template
 * @param {Object} input - User input parameters
 * @param {Object} result - Calculation results
 * @returns {string} Complete HTML document as string
 */
export const generatePDFTemplate = (input, result) => {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Filter Housing Selection Report - ${input.customerName || 'Customer'}</title>
      <meta charset="UTF-8">
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        @page {
          size: A4;
          margin: 15mm;
        }
        
        body {
          font-family: 'Inter', sans-serif;
          color: #1e293b;
          background: white;
          font-size: 11px;
          line-height: 1.4;
        }
        
        .page-container {
          width: 100%;
          max-width: 210mm;
          margin: 0 auto;
        }
        
        .header {
          text-align: center;
          margin-bottom: 20px;
          padding-bottom: 12px;
          border-bottom: 3px solid #2563eb;
        }
        
        .company-name {
          font-size: 32px;
          font-weight: 800;
          color: #2563eb;
          letter-spacing: 6px;
          margin-bottom: 8px;
        }
        
        .report-title {
          font-size: 18px;
          font-weight: 700;
          color: #1e293b;
          margin-bottom: 4px;
        }
        
        .report-subtitle {
          font-size: 11px;
          color: #64748b;
          font-weight: 500;
          margin-bottom: 6px;
        }
        
        .customer-info {
          font-size: 12px;
          color: #1e293b;
          font-weight: 600;
          margin-bottom: 6px;
        }
        
        .report-date {
          font-size: 10px;
          color: #94a3b8;
        }
        
        .section {
          margin-bottom: 18px;
          page-break-inside: avoid;
        }
        
        .section-title {
          font-size: 12px;
          font-weight: 700;
          color: #1e293b;
          margin-bottom: 10px;
          padding-left: 8px;
          border-left: 3px solid #2563eb;
        }
        
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 0;
          font-size: 10px;
        }
        
        th {
          background: #f1f5f9;
          padding: 8px 12px;
          text-align: left;
          font-weight: 600;
          color: #475569;
          border: 1px solid #cbd5e1;
        }
        
        td {
          padding: 7px 12px;
          border: 1px solid #e2e8f0;
          color: #1e293b;
        }
        
        td:first-child {
          font-weight: 500;
          color: #475569;
          width: 50%;
        }
        
        td:last-child {
          font-weight: 600;
          color: #1e293b;
        }
        
        tbody tr:nth-child(even) {
          background: #f8fafc;
        }
        
        .housing-section {
          margin-top: 15px;
          padding: 18px;
          background: linear-gradient(135deg, #f8fafc 0%, #dbeafe 100%);
          border-radius: 8px;
          border: 2px solid #bfdbfe;
          text-align: center;
        }
        
        .housing-label {
          font-size: 11px;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 1px;
          margin-bottom: 8px;
        }
        
        .housing-model {
          font-size: 26px;
          font-weight: 800;
          color: #2563eb;
          letter-spacing: 2px;
        }
        
        .notes-section {
          margin-top: 15px;
          padding: 12px 15px;
          background: #fefce8;
          border-left: 3px solid #eab308;
          border-radius: 6px;
        }
        
        .notes-title {
          font-size: 11px;
          font-weight: 700;
          color: #1e293b;
          margin-bottom: 6px;
        }
        
        .notes-section ul {
          margin-left: 18px;
          color: #475569;
        }
        
        .notes-section li {
          margin-bottom: 4px;
          font-size: 9px;
          line-height: 1.4;
        }
        
        .notes-section li strong {
          color: #1e293b;
          font-weight: 600;
        }
        
        .footer {
          margin-top: 15px;
          padding-top: 10px;
          border-top: 1px solid #e2e8f0;
          text-align: center;
          font-size: 8px;
          color: #94a3b8;
        }
        
        .footer p {
          margin: 2px 0;
        }
        
        @media print {
          body {
            font-size: 10px;
          }
          
          .page-container {
            max-width: 100%;
          }
          
          .section {
            page-break-inside: avoid;
          }
        }
      </style>
    </head>
    <body>
      <div class="page-container">
        <div class="header">
          <div class="company-name">BEKO</div>
          <div class="report-title">Filter Housing Selection Report</div>
          <div class="report-subtitle">Advanced Biogas Filter Sizing Calculator</div>
          ${input.customerName ? `<div class="customer-info">Customer: ${input.customerName}</div>` : ''}
          <div class="report-date">Generated On: ${formatDate()}</div>
        </div>
        
        <div class="section">
          <div class="section-title">1. Configuration Parameters</div>
          <table>
            <thead>
              <tr>
                <th>Parameter</th>
                <th>Value</th>
              </tr>
            </thead>
            <tbody>
              ${input.customerName ? `
              <tr>
                <td>Customer Name</td>
                <td><strong>${input.customerName}</strong></td>
              </tr>
              ` : ''}
              <tr>
                <td>Filter Type</td>
                <td>${input.filterType}</td>
              </tr>
              <tr>
                <td>Filter Scope</td>
                <td>${input.filterScope}</td>
              </tr>
              <tr>
                <td>Gas Type</td>
                <td>${input.gas}</td>
              </tr>
              <tr>
                <td>Flow Rate</td>
                <td><strong>${input.flow} m³/hr</strong></td>
              </tr>
              <tr>
                <td>Minimum Working Pressure</td>
                <td><strong>${input.minPressure} barg</strong></td>
              </tr>
              ${input.maxPressure ? `
              <tr>
                <td>Maximum Pressure</td>
                <td>${input.maxPressure} barg</td>
              </tr>
              ` : ''}
              <tr>
                <td>Inlet Air Temperature</td>
                <td><strong>${input.temperature} °C</strong></td>
              </tr>
              <tr>
                <td>End Connection (DN)</td>
                <td>${input.endConnection}</td>
              </tr>
              <tr>
                <td>MOC of Housing</td>
                <td>${input.moc}</td>
              </tr>
              ${input.filterType === "Suction" && input.moistureContent ? `
              <tr>
                <td>Simplex Moisture Content</td>
                <td>${input.moistureContent}</td>
              </tr>
              ` : ''}
              ${input.oilContent ? `
              <tr>
                <td>Inlet Oil Content</td>
                <td>${input.oilContent} ${input.filterType === "Suction" ? "mg/m³" : "ppm"}</td>
              </tr>
              ` : ''}
              ${input.dustContent ? `
              <tr>
                <td>Inlet Dust Content</td>
                <td>${input.dustContent} micron</td>
              </tr>
              ` : ''}
              <tr>
                <td>Outlet Filtration</td>
                <td><strong>${input.DuplexFiltration} micron</strong></td>
              </tr>
              ${input.DuplexOilResidual ? `
              <tr>
                <td>Outlet Oil Residual</td>
                <td>${input.DuplexOilResidual} mg/m³</td>
              </tr>
              ` : ''}
              ${input.filterType === "Discharge" ? `
              <tr>
                <td>Fittings</td>
                <td>${input.fittings}</td>
              </tr>
              <tr>
                <td>Type of Drain</td>
                <td>${input.drainType}</td>
              </tr>
              ` : ''}
            </tbody>
          </table>
        </div>
        
        <div class="section">
          <div class="section-title">2. Selected Housing Model</div>
          <div class="housing-section">
            <div class="housing-label">Recommended Housing Model</div>
            <div class="housing-model">${result.housing}</div>
          </div>
        </div>
        
        <div class="notes-section">
          <div class="notes-title">Notes:</div>
          <ul>
            <li><strong>Housing selection</strong> is based on corrected flow capacity and filtration requirements.</li>
            <li>This report is generated using BEKO's internal sizing logic and should be used <strong>for technical evaluation</strong> and reference.</li>
            <li>Please verify all specifications with BEKO technical team before final procurement.</li>
          </ul>
        </div>
        
        <div class="footer">
          <p>This report was generated by BEKO Filter Housing Selection Calculator</p>
          <p>© ${new Date().getFullYear()} BEKO Technologies. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `;
};

/**
 * Generate and open PDF in new window
 * @param {Object} input - User input parameters
 * @param {Object} result - Calculation results
 */
export const generatePDF = (input, result) => {
  const printWindow = window.open('', '_blank');
  
  if (!printWindow) {
    alert('Please allow popups to generate PDF');
    return;
  }
  
  const htmlContent = generatePDFTemplate(input, result);
  
  // Set the title with customer name and date
  const customerName = input.customerName || 'Customer';
  const dateStr = formatDateForFilename();
  const filename = `${customerName}_${dateStr}_Filter_Report`;
  
  printWindow.document.write(htmlContent);
  printWindow.document.title = filename;
  printWindow.document.close();
  
  // Wait for content to load, then print
  printWindow.onload = function() {
    setTimeout(() => {
      printWindow.print();
    }, 250);
  };
};
