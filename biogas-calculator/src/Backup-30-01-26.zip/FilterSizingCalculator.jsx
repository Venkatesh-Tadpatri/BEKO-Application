import React, { useState } from "react";
import CONFIG from "./filterConfig.json";
import {
  getPressureFactor,
  getTempFactor,
  selectHousing,
  getAppropriatePressureTier
} from "./filterUtils";
import { generatePDF } from "./pdfGenerator";
import "./FilterSizingCalculator.css";

export default function FilterSizingCalculator() {
  const DEFAULT_SUCTION_INPUT = {
    customerName: "",
    filterType: "",
    filterScope: "",
    gas: "",
    flow: "",
    minPressure: "",
    maxPressure: "",
    temperature: "",
    endConnection: "",
    moistureContent: "",
    oilContent: "",
    dustContent: "",
    DuplexFiltration: "",
    DuplexOilResidual: "",
    moc: ""
  };

  const DEFAULT_DISCHARGE_INPUT = {
    customerName: "",
    filterType: "",
    filterScope: "",
    gas: "",
    flow: "",
    minPressure: "",
    maxPressure: "",
    temperature: "",
    endConnection: "",
    oilContent: "",
    dustContent: "",
    DuplexFiltration: "",
    DuplexOilResidual: "",
    fittings: "",
    drainType: "",
    moc: ""
  };

  const [result, setResult] = useState(null);
  const [input, setInput] = useState({
    customerName: "",
    filterType: "",
    filterScope: "",
    gas: "",
    flow: "",
    minPressure: "",
    maxPressure: "",
    temperature: "",
    endConnection: "",
    moistureContent: "",
    oilContent: "",
    dustContent: "",
    DuplexFiltration: "",
    DuplexOilResidual: "",
    fittings: "",
    drainType: "",
    moc: ""
  });
  const [showCalculations, setShowCalculations] = useState(false);

  const calculate = () => {
    // Validate required fields only
    if (!input.filterType) {
      alert("Please select Type of Filter");
      return;
    }
    if (!input.gas) {
      alert("Please select Type of Gas");
      return;
    }
    if (!input.flow) {
      alert("Please enter Flow Rate");
      return;
    }
    if (!input.minPressure) {
      alert("Please enter Min. Working Pressure");
      return;
    }
    if (!input.temperature) {
      alert("Please enter Inlet Air Temperature");
      return;
    }
    if (!input.DuplexFiltration) {
      alert("Please select Outlet Filtration (micron)");
      return;
    }

    const gas = CONFIG.gases[input.gas];
    const gasFactor = gas.gasFactor;
    const mwra = gas.mwra;

    const pf = getPressureFactor(input.filterType, input.minPressure, CONFIG.pressureFactors);
    const tf = getTempFactor(input.temperature, CONFIG.temperature.base);

    const totalFactor = gasFactor * pf * tf;
    const initialFlow = Number(input.flow) / totalFactor;
    const finalFlow = initialFlow * mwra;

    let models;
    if (input.filterType === "Suction") {
      models = CONFIG.suctionModels;
    } else {
      const targetPressure = getAppropriatePressureTier(input.minPressure);
      models = CONFIG.dischargeModels.filter(
        m => m.pressure === targetPressure && !CONFIG.exclusions.includes(m.model)
      );
    }

    const housing = selectHousing(models, finalFlow);

    setResult({
      gasFactor,
      mwra,
      pf,
      tf,
      totalFactor,
      initialFlow,
      finalFlow,
      housing:
        housing.model +
        CONFIG.suffixes.filtration[input.DuplexFiltration] +
        CONFIG.suffixes.dp +
        CONFIG.suffixes.drain,
      moc: input.moc,
      drainType: input.filterType === "Discharge" ? input.drainType : "Manual Drain",
      fittings: input.filterType === "Discharge" ? input.fittings : null
    });
    
    // Reset calculations view when new calculation is done
    setShowCalculations(false);
  };

  const resetForm = () => {
    setInput({
      customerName: "",
      filterType: "",
      filterScope: "",
      gas: "",
      flow: "",
      minPressure: "",
      maxPressure: "",
      temperature: "",
      endConnection: "",
      moistureContent: "",
      oilContent: "",
      dustContent: "",
      DuplexFiltration: "",
      DuplexOilResidual: "",
      fittings: "",
      drainType: "",
      moc: ""
    });
    setResult(null);
    setShowCalculations(false);
  };

  const handleFilterTypeChange = (newType) => {
    setInput({ ...input, filterType: newType });
    setResult(null);
    setShowCalculations(false);
  };

  const handlePrintPDF = () => {
    if (!result) {
      alert("Please calculate the selection first before generating PDF");
      return;
    }
    generatePDF(input, result);
  };

  return (
    <div className="page">
      <div className="container">
        <div className="card">
          <div className="card-header">
            <div className="header-content">
              <div className="header-top">
                <div className="icon-wrapper">♻️</div>
                <div>
                  <h1>Filter Housing Selection</h1>
                  <p className="header-subtitle">
                    Advanced biogas filter sizing calculator
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="card-body">
            <div className="section-title">Configuration Parameters</div>

            <div className="grid">
              {/* Customer Name */}
              <div className="form-group">
                <label className="form-label">
                  Customer Name <span className="optional">(optional)</span>
                </label>
                <input
                  type="text"
                  value={input.customerName}
                  onChange={e => setInput({ ...input, customerName: e.target.value })}
                  placeholder="Enter customer name"
                />
              </div>

              {/* Filter Type */}
              <div className="form-group">
                <label className="form-label">
                  Type of Filter <span className="required">*</span>
                </label>
                <select 
                  value={input.filterType} 
                  onChange={e => handleFilterTypeChange(e.target.value)}
                >
                  <option value="">-- Select Filter Type --</option>
                  <option>Suction</option>
                  <option>Discharge</option>
                </select>
              </div>

              {/* Filter Scope */}
              <div className="form-group">
                <label className="form-label">
                  Filter Scope <span className="optional">(optional)</span>
                </label>
                <select 
                  value={input.filterScope} 
                  onChange={e => setInput({ ...input, filterScope: e.target.value })}
                >
                  <option value="">-- Select Filter Scope --</option>
                  {CONFIG.filterScopes.map(scope => (
                    <option key={scope}>{scope}</option>
                  ))}
                </select>
              </div>

              {/* Gas Type */}
              <div className="form-group">
                <label className="form-label">
                  Type of Gas <span className="required">*</span>
                </label>
                <select 
                  value={input.gas} 
                  onChange={e => setInput({ ...input, gas: e.target.value })}
                >
                  <option value="">-- Select Gas Type --</option>
                  {Object.keys(CONFIG.gases).map(g => (
                    <option key={g}>{g}</option>
                  ))}
                </select>
              </div>

              {/* Flow Rate */}
              <div className="form-group">
                <label className="form-label">
                  Flow (m³/hr) <span className="required">*</span>
                </label>
                <div className="input-wrapper">
                  <input
                    type="number"
                    value={input.flow}
                    onChange={e => setInput({ ...input, flow: e.target.value })}
                    placeholder="Enter flow rate"
                  />
                  <span className="input-unit">m³/hr</span>
                </div>
              </div>

              {/* Min Working Pressure */}
              <div className="form-group">
                <label className="form-label">
                  Min. Working Pressure (barg) <span className="required">*</span>
                </label>
                <div className="input-wrapper">
                  <input
                    type="number"
                    value={input.minPressure}
                    onChange={e => setInput({ ...input, minPressure: e.target.value })}
                    placeholder="Enter min pressure"
                  />
                  <span className="input-unit">barg</span>
                </div>
              </div>

              {/* Max Pressure */}
              <div className="form-group">
                <label className="form-label">
                  Max. Pressure (barg)
                </label>
                <div className="input-wrapper">
                  <input
                    type="number"
                    value={input.maxPressure}
                    onChange={e => setInput({ ...input, maxPressure: e.target.value })}
                    placeholder="Enter max pressure"
                  />
                  <span className="input-unit">barg</span>
                </div>
              </div>

              {/* Inlet Air Temperature */}
              <div className="form-group">
                <label className="form-label">
                  Inlet Air Temperature (Deg.C) <span className="required">*</span>
                </label>
                <div className="input-wrapper">
                  <input
                    type="number"
                    value={input.temperature}
                    onChange={e => setInput({ ...input, temperature: e.target.value })}
                    placeholder="Enter temperature"
                  />
                  <span className="input-unit">°C</span>
                </div>
              </div>

              {/* End Connection */}
              <div className="form-group">
                <label className="form-label">
                  End Connection (DN) <span className="optional">(optional)</span>
                </label>
                <select 
                  value={input.endConnection} 
                  onChange={e => setInput({ ...input, endConnection: e.target.value })}
                >
                  <option value="">-- Select Connection --</option>
                  {CONFIG.endConnections.map(conn => (
                    <option key={conn}>{conn}</option>
                  ))}
                </select>
              </div>

              {/* MOC of Housing */}
              <div className="form-group">
                <label className="form-label">
                  MOC of Housing <span className="optional">(optional)</span>
                </label>
                <select 
                  value={input.moc} 
                  onChange={e => setInput({ ...input, moc: e.target.value })}
                >
                  <option value="">-- Select MOC --</option>
                  {CONFIG.mocOptions.map(moc => (
                    <option key={moc}>{moc}</option>
                  ))}
                </select>
              </div>

              {/* Moisture Content - Suction Only */}
              {input.filterType === "Suction" && (
                <div className="form-group">
                  <label className="form-label">Simplex Moisture Content</label>
                  <input
                    type="text"
                    value={input.moistureContent}
                    onChange={e => setInput({ ...input, moistureContent: e.target.value })}
                    placeholder="Enter moisture content"
                  />
                </div>
              )}

              {/* Oil Content */}
              <div className="form-group">
                <label className="form-label">
                  Inlet Oil Content {input.filterType === "Suction" ? "(mg/m3)" : "(ppm)"} <span className="optional">(optional)</span>
                </label>
                <div className="input-wrapper">
                  <input
                    type="number"
                    value={input.oilContent}
                    onChange={e => setInput({ ...input, oilContent: e.target.value })}
                    placeholder="Enter oil content"
                  />
                  <span className="input-unit">{input.filterType === "Suction" ? "mg/m³" : "ppm"}</span>
                </div>
              </div>

              {/* Dust Content */}
              <div className="form-group">
                <label className="form-label">
                  Inlet Dust Content (micron) <span className="optional">(optional)</span>
                </label>
                <div className="input-wrapper">
                  <input
                    type="number"
                    value={input.dustContent}
                    onChange={e => setInput({ ...input, dustContent: e.target.value })}
                    placeholder="Enter dust content"
                  />
                  <span className="input-unit">micron</span>
                </div>
              </div>

              {/* Duplex Filtration */}
              <div className="form-group">
                <label className="form-label">
                  Outlet Filtration (micron) <span className="required">*</span>
                </label>
                <select 
                  value={input.DuplexFiltration} 
                  onChange={e => setInput({ ...input, DuplexFiltration: Number(e.target.value) })}
                >
                  <option value="">-- Select Filtration --</option>
                  <option value={25}>25 micron</option>
                  <option value={5}>5 micron</option>
                  <option value={1}>1 micron</option>
                  <option value={0.01}>0.01 micron</option>
                  <option value={0.003}>0.003 mg/m3</option>
                </select>
              </div>

              {/* Duplex Oil Residual */}
              <div className="form-group">
                <label className="form-label">Outlet Oil Residual (mg/m3)</label>
                <div className="input-wrapper">
                  <input
                    type="number"
                    value={input.DuplexOilResidual}
                    onChange={e => setInput({ ...input, DuplexOilResidual: e.target.value })}
                    placeholder="Enter oil residual"
                  />
                  <span className="input-unit">mg/m³</span>
                </div>
              </div>

              {/* Discharge Filter Specific Fields */}
              {input.filterType === "Discharge" && (
                <>
                  {/* Fittings */}
                  <div className="form-group">
                    <label className="form-label">
                      Fittings <span className="optional">(optional)</span>
                    </label>
                    <select 
                      value={input.fittings} 
                      onChange={e => setInput({ ...input, fittings: e.target.value })}
                    >
                      <option value="">-- Select Fittings --</option>
                      {CONFIG.fittingsOptions.map(fitting => (
                        <option key={fitting}>{fitting}</option>
                      ))}
                    </select>
                  </div>

                  {/* Drain Type */}
                  <div className="form-group">
                    <label className="form-label">
                      Type of Drain <span className="optional">(optional)</span>
                    </label>
                    <select 
                      value={input.drainType} 
                      onChange={e => setInput({ ...input, drainType: e.target.value })}
                    >
                      <option value="">-- Select Drain Type --</option>
                      <option>Manual Drain</option>
                      <option>Other</option>
                    </select>
                  </div>
                </>
              )}
            </div>

            <div className="button-group">
              <button className="btn btn-primary" onClick={calculate}>
                <span>🔍</span> Calculate Selection
              </button>
              <button className="btn btn-secondary" onClick={resetForm}>
                <span>↻</span> Reset Form
              </button>
              {result && (
                <>
                  <button className="btn btn-pdf" onClick={handlePrintPDF}>
                    <span>📄</span> Print to PDF
                  </button>
                  <button 
                    className="btn btn-calculations" 
                    onClick={() => setShowCalculations(!showCalculations)}
                  >
                    <span>📊</span> {showCalculations ? 'Hide' : 'View'} Calculations
                  </button>
                </>
              )}
            </div>

            {result && !showCalculations && (
              <div className="result-section">
                <div className="section-title">Result</div>
                
                <div className="result-card">
                  <div className="final-result">
                    <div className="final-result-content">
                      <div className="final-result-grid">
                        <div className="final-result-item">
                          <div className="final-label">Selected Housing Model</div>
                          <div className="final-value">{result.housing}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {result && showCalculations && (
              <div className="result-section">
                <div className="section-title">Detailed Calculation Results</div>
                
                <div className="result-card">
                  <div className="result-grid">
                    <div className="result-item">
                      <div className="result-label">Gas Factor</div>
                      <div className="result-value">{result.gasFactor}</div>
                    </div>

                    <div className="result-item">
                      <div className="result-label">MWrA Factor</div>
                      <div className="result-value">{result.mwra}</div>
                    </div>

                    <div className="result-item">
                      <div className="result-label">Pressure Factor</div>
                      <div className="result-value">{result.pf.toFixed(3)}</div>
                    </div>

                    <div className="result-item">
                      <div className="result-label">Temperature Factor</div>
                      <div className="result-value">{result.tf.toFixed(3)}</div>
                    </div>

                    <div className="result-item">
                      <div className="result-label">Total Factor</div>
                      <div className="result-value">{result.totalFactor.toFixed(3)}</div>
                    </div>

                    <div className="result-item">
                      <div className="result-label">Initial Flow</div>
                      <div className="result-value">{result.initialFlow.toFixed(2)} m³/hr</div>
                    </div>

                    <div className="result-item">
                      <div className="result-label">Final Flow</div>
                      <div className="result-value">{result.finalFlow.toFixed(2)} m³/hr</div>
                    </div>
                  </div>

                  <div className="final-result">
                    <div className="final-result-content">
                      <div className="final-result-grid">
                        <div className="final-result-item">
                          <div className="final-label">Selected Housing Model</div>
                          <div className="final-value">{result.housing}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
